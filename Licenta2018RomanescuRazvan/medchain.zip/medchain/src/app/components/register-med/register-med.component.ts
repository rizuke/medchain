import { Component, OnInit } from '@angular/core';
import { Buffer } from 'buffer';
import { GovManagementService, IpfsService, EncryptionService, Web3jsService } from '../../services';
import { MedicalEntityType } from '../../models';

@Component({
  selector: 'app-register-med',
  templateUrl: './register-med.component.html',
  styleUrls: ['./register-med.component.scss']
})
export class RegisterMedComponent implements OnInit {
  public govAddress: string;
  public entityType: string;
  public name: string;
  public establishmentAddress: string;
  public fileHash: string;
  public processedFile;

  constructor(
    private web3Service: Web3jsService,
    private govManagementService: GovManagementService,
    private ipfsService: IpfsService,
    private encryptionService: EncryptionService) { }

  ngOnInit() {
  }

  public async addMedicalEntityRequest() {
    let medEntityIdentification = this.web3Service.currentAccount;

    let medEntityType = MedicalEntityType.Individual;
    if (this.entityType == '0') {
      medEntityType = MedicalEntityType.Individual;
    }
    else if (this.entityType == '1') {
      medEntityType = MedicalEntityType.PublicHospital;
    }
    else if (this.entityType == '2') {
      medEntityType = MedicalEntityType.PrivateHospital;
    }

    await this.ipfsService.ipfsObject.add(this.processedFile, (error, result) => {
      if (error) {
        console.log(error);
        return;
      }

      this.fileHash = result[0].hash;
      console.log(this.fileHash);

      this.govManagementService.addMedicalEntityRequest(medEntityIdentification, this.govAddress, medEntityType, false, 0, 0, this.name, this.establishmentAddress, this.fileHash);
    })
  }

  public handleFileUpload(event) {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.readAsArrayBuffer(file);
    reader.onloadend = () => {
      this.processedFile = new Buffer(<string>reader.result);
      console.log(this.processedFile);
    }
  }
}

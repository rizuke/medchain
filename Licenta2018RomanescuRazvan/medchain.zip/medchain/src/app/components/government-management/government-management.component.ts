import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-government-management',
  templateUrl: './government-management.component.html',
  styleUrls: ['./government-management.component.scss']
})
export class GovernmentManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

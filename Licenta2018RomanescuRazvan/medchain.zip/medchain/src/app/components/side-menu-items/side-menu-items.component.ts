import { Component, OnInit, Input } from '@angular/core';
import { UserType } from '../../models';
import { UserService, Web3jsService } from '../../services';
import { from } from 'rxjs';
import { NbMenuItem } from '@nebular/theme';
import { patientNavItems, medEntityNavItems, govNavItems, authorityNavItems } from './../../models/MenuItems';

@Component({
  selector: 'app-side-menu-items',
  templateUrl: './side-menu-items.component.html',
  styleUrls: ['./side-menu-items.component.scss']
})
export class SideMenuItemsComponent implements OnInit {
  @Input() menuType;

  public navItems: NbMenuItem[] = [];

  private intervalId;

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.intervalId = setInterval(() => this.setNavItemsListGivenMenuType(), 100);
  }

  private setNavItemsListGivenMenuType() {
    let observable = from(this.userService.getUserTypeForCurrentUser());
    let userType: UserType = UserType.Unregistered;

    observable.subscribe(
      (result) => {
        userType = result;

        if (userType == UserType.Patient) {
          this.navItems = patientNavItems;
        }
        else if (userType == UserType.MedicalEntity) {
          this.navItems = medEntityNavItems;
        }
        else if (userType == UserType.Government) {
          this.navItems = govNavItems;
        }
        else if (userType == UserType.Authority) {
          this.navItems = authorityNavItems;
        }

        clearInterval(this.intervalId);
      },
      (error) => {
        // console.log(error);
      }
    )
  }
}

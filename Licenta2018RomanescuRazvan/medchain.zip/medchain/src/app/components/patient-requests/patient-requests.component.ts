import { Component, OnInit } from '@angular/core';
import { Web3jsService, AddressBookService } from '../../services';
import { from } from 'rxjs';

@Component({
  selector: 'app-patient-requests',
  templateUrl: './patient-requests.component.html',
  styleUrls: ['./patient-requests.component.scss']
})
export class PatientRequestsComponent implements OnInit {
  private intervalId;
  public patientRequests;

  constructor(
    private web3Service: Web3jsService,
    private addressBookService: AddressBookService
  ) { }

  ngOnInit() {
    this.intervalId = setInterval(() => this.getPatientRequests(), 100);
  }

  public getPatientRequests() {
    let currentUser = this.web3Service.currentAccount;
    let observable = from(this.addressBookService.getPatientRequests(currentUser));
    
    observable.subscribe(
      (result) => {
        this.patientRequests = result;
        clearInterval(this.intervalId);
      },
      (error) => { }
    )
  }

  public handleRequestSolved(event) {
    this.patientRequests = this.patientRequests.filter(r => r.identification != event);
  }
}

import { Component, OnInit } from '@angular/core';
import { GovManagementService, Web3jsService } from '../../services';
import { from } from 'rxjs';

@Component({
  selector: 'app-med-entity-requests',
  templateUrl: './med-entity-requests.component.html',
  styleUrls: ['./med-entity-requests.component.scss']
})
export class MedEntityRequestsComponent implements OnInit {
  private intervalId;
  public medEntityRequests;

  constructor(
    private web3Service: Web3jsService,
    private govManagementService: GovManagementService) { }

  ngOnInit() {
    this.intervalId = setInterval(() => this.getMedicalEntityRequests(), 100);
  }

  public getMedicalEntityRequests() {
    let currentUser = this.web3Service.currentAccount;
    let observable = from(this.govManagementService.getGovMedicalEntitiesRequests(currentUser));

    observable.subscribe(
      (result) => {
        this.medEntityRequests = result;
        console.log(result);
        clearInterval(this.intervalId);
      },
      (error) => { }
    )
  }

  public handleRequestSolved(event) {
    this.medEntityRequests = this.medEntityRequests.filter(r => r.identification != event);
  }
}

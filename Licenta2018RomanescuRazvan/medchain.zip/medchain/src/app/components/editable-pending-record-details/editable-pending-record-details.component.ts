import { Component, OnInit, Input } from '@angular/core';
import { RecordType, MedicineBranch } from '../../models';
import { MenuItem, SelectItem } from 'primeng/api';
import { Buffer } from 'buffer';
import { HealthWalletService, IpfsService, Web3jsService } from '../../services';

@Component({
  selector: 'app-editable-pending-record-details',
  templateUrl: './editable-pending-record-details.component.html',
  styleUrls: ['./editable-pending-record-details.component.scss']
})
export class EditablePendingRecordDetailsComponent implements OnInit {
  @Input() pendingRecord;

  // public recordDescription;
  public editMode = false;

  public items: MenuItem[];
  activeIndex: number = 0;

  public processedFile;

  public isUrgency: boolean;
  public isDiagnostic: boolean;
  public selectedRecordType;
  public selectedMedicineBranch;
  public addedDate: Date;
  public recordName: string;
  public recordDescription: string;
  public medicalEntityName: string;
  public rootId: number;
  public fileHash: string;

  public recordTypes: SelectItem[] = [
    { label: "Regular Check", value: "0" },
    { label: "Diagnostic", value: "1" },
    { label: "Treatment", value: "2" },
    { label: "Prescription", value: "3" },
    { label: "Hospitalization", value: "4" },
    { label: "Vaccination", value: "5" },
    { label: "Surgery", value: "6" },
    { label: "Prosthetics", value: "7" },
    { label: "Transplants", value: "8" },
    { label: "Record Correction", value: "9" },
    { label: "Others", value: "10" },
  ];

  public medicineBranches: SelectItem[] = [
    { label: "General", value: "0" },
    { label: "Cardiology", value: "1" },
    { label: "Dentistry", value: "2" },
    { label: "Endocrinology", value: "2" },
    { label: "Gastroenterology", value: "2" },
    { label: "Hematology", value: "2" },
    { label: "Kinetotherapy", value: "2" },
    { label: "Work Medicine", value: "2" },
    { label: "Neurosurgery", value: "2" },
    { label: "Neurology", value: "2" },
    { label: "Pediatric Neurology", value: "2" },
    { label: "Ginecology", value: "2" },
    { label: "Ophtalmology", value: "2" },
    { label: "Oncology", value: "2" },
    { label: "ORL", value: "2" },
    { label: "PediatricOrtopedy", value: "2" },
    { label: "Pneumology", value: "2" },
    { label: "Psychology", value: "2" },
    { label: "Radiology", value: "2" },
    { label: "Rheumatology", value: "2" },
    { label: "Hospitalization", value: "2" },
    { label: "Urology", value: "2" },
    { label: "Other", value: "2" },
  ]

  constructor(
    private web3Service: Web3jsService,
    private healthWalletService: HealthWalletService,
    private ipfsService: IpfsService
  ) { }

  ngOnInit() {
    this.recordDescription = this.pendingRecord.recordDescription;

    this.items = [{
      label: 'Basics',
      command: (event: any) => {
        this.activeIndex = 0;
      }
    },
    {
      label: 'Categories',
      command: (event: any) => {
        this.activeIndex = 1;
      }
    },
    {
      label: 'Record Details',
      command: (event: any) => {
        this.activeIndex = 2;
      }
    },
    {
      label: 'Files & Linkage',
      command: (event: any) => {
        this.activeIndex = 3;
      }
    }
    ];
  }

  public getRecordType() {
    return RecordType[parseInt(this.pendingRecord.recordType)];
  }

  public getMedicineBranch() {
    return MedicineBranch[parseInt(this.pendingRecord.medicineBranch)];
  }

  public getFileLink() {
    return "https://ipfs.io/ipfs/" + this.pendingRecord.fileHash;
  }

  public async enterEditMode() {
    this.editMode = true;
    this.isUrgency = await this.healthWalletService.checkIfRecordIsForUrgency(this.pendingRecord.id);
    this.isDiagnostic = this.pendingRecord.isDiagnostic;
    this.selectedRecordType = this.pendingRecord.recordType;
    this.selectedMedicineBranch = this.pendingRecord.medicineBranch;
    this.recordName = this.pendingRecord.recordName;
    this.recordDescription = this.pendingRecord.recordDescription;
    this.medicalEntityName = this.pendingRecord.medicalEntityName;
    this.addedDate = this.pendingRecord.addedDate;
    this.fileHash = "";
    this.rootId = this.pendingRecord.rootId;
  }

  public async editRecord() {
    if (this.fileHash == "") {
      this.fileHash = this.pendingRecord.fileHash;

      await this.healthWalletService.editRecordFromMedEntityQueue(this.pendingRecord.id, this.isUrgency, this.selectedRecordType, this.selectedMedicineBranch, Math.round(Date.now() / 1000), this.recordName, this.recordDescription, this.medicalEntityName, this.pendingRecord.medicalEntity, this.fileHash, this.rootId);
    }
    else {
      await this.ipfsService.ipfsObject.add(this.processedFile, (error, result) => {
        if (error) {
          console.log(error);
          return;
        }

        this.fileHash = result[0].hash;
        console.log(this.fileHash);

        this.healthWalletService.editRecordFromMedEntityQueue(this.pendingRecord.id, this.isUrgency, this.selectedRecordType, this.selectedMedicineBranch, Math.round(Date.now() / 1000), this.recordName, this.recordDescription, this.medicalEntityName, this.pendingRecord.medicalEntity, this.fileHash, this.rootId);
      });
    }

    this.pendingRecord.selectedRecordType = this.selectedRecordType;
    this.pendingRecord.selectedMedicineBranch = this.selectedMedicineBranch;
    this.pendingRecord.recordName = this.recordName;
    this.pendingRecord.recordDescription = this.recordDescription;
    this.pendingRecord.medicalEntityName = this.medicalEntityName;
    this.pendingRecord.fileHash = this.fileHash;
    this.pendingRecord.rootId = this.rootId;

    this.editMode = false;
  }

  public sendBack() {
    this.editMode = false;
    this.healthWalletService.addRecordFromMedEntityQueueToPatientHistoryDirectly(this.pendingRecord.patient, this.pendingRecord.medicalEntity, this.pendingRecord.id);
  }

  public handleFileUpload(event) {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.readAsArrayBuffer(file);
    reader.onloadend = () => {
      this.processedFile = new Buffer(<string>reader.result);
    }
  }
}

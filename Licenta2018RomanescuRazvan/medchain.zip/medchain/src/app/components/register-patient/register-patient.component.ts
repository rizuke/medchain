import { Component, OnInit } from '@angular/core';
import { AddressBookService, EncryptionService, Web3jsService } from '../../services';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register-patient',
  templateUrl: './register-patient.component.html',
  styleUrls: ['./register-patient.component.scss']
})
export class RegisterPatientComponent implements OnInit {
  public countryId: string;
  public medicalId: string;
  public medEntityAddress: string;
  public firstName: string;
  public lastName: string;
  public birthdate: Date;
  public residency: string;

  constructor(
    private encryptionService: EncryptionService,
    private web3Service: Web3jsService,
    private addressBookService: AddressBookService,
    private router: Router) { }

  ngOnInit() {

  }

  public registerPatient() {
    let key = this.countryId + this.medicalId;
    let encryptedKey = this.encryptionService.encrypt(key, key);

    console.log(key + " " + encryptedKey);

    let patientIdentification = this.web3Service.currentAccount;

    // let encfirstName = this.encryptionService.encrypt(key, this.firstName);
    // let enclastName = this.encryptionService.encrypt(key, this.lastName);
    // let encDate = (this.birthdate.getTime() / 1000);
    // let encResidency = this.encryptionService.encrypt(key, this.residency);

    this.addressBookService.registerPatientIdentification(encryptedKey);
    // this.addressBookService.addPatientDetails(patientIdentification, encfirstName, enclastName, encDate, encResidency, this.medEntityAddress);
    this.addressBookService.addPatientDetails(patientIdentification, this.firstName, this.lastName, this.birthdate.getTime() / 1000, this.residency, this.medEntityAddress).then(() => {
      this.router.navigate(['/']);
    });
  }
}

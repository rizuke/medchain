import { Component, OnInit } from '@angular/core';
import { AddressBookService, EncryptionService, Web3jsService } from '../../services';
import { faFirstAid } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-register-patient',
  templateUrl: './register-patient.component.html',
  styleUrls: ['./register-patient.component.scss']
})
export class RegisterPatientComponent implements OnInit {
  public countryId: string;
  public medicalId: string;
  public medEntityAddress: string;
  public firstName: string;
  public lastName: string;
  public birthdate: Date;
  public residency: string;

  constructor(
    private encryptionService: EncryptionService,
    private web3Service: Web3jsService,
    private addressBookService: AddressBookService) { }

  ngOnInit() {

  }

  public registerPatient() {
    let key = this.countryId + this.medicalId;
    let encryptedKey = this.encryptionService.encrypt(key, key);

    let patientIdentification = this.web3Service.currentAccount;

    let encfirstName = this.encryptionService.encrypt(key, this.firstName);
    let enclastName = this.encryptionService.encrypt(key, this.lastName);
    let encDate = (this.birthdate.getTime() / 1000);
    let encResidency = this.encryptionService.encrypt(key, this.residency);

    this.addressBookService.registerPatientIdentification(encryptedKey);
    this.addressBookService.addPatientDetails(patientIdentification, encfirstName, enclastName, encDate, encResidency, this.medEntityAddress);
  }
}

import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Web3jsService, GovManagementService } from '../../services';

@Component({
  selector: 'app-med-entity-request-details',
  templateUrl: './med-entity-request-details.component.html',
  styleUrls: ['./med-entity-request-details.component.scss']
})
export class MedEntityRequestDetailsComponent implements OnInit {
  @Input() medEntityRequest;
  @Output() requestSolved: EventEmitter<any> = new EventEmitter();
  
  constructor(
    private web3Service: Web3jsService,
    private govManagementService: GovManagementService
  ) { }

  ngOnInit() {
  }

  public acceptRequest() {
    console.log(this.medEntityRequest);
    this.govManagementService.acceptMedicalEntityRequest(this.medEntityRequest.identification);
    this.requestSolved.emit(this.medEntityRequest.identification);
  }

  public declineRequest() {
    this.govManagementService.declineMedicalEntityRequest(this.medEntityRequest.identification);
    this.requestSolved.emit(this.medEntityRequest.identification);
  }
}

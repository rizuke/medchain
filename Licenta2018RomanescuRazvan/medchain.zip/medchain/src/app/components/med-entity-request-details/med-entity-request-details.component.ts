import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { GovManagementService, ToastService } from '../../services';
import { MedicalEntityType } from '../../models';

@Component({
  selector: 'app-med-entity-request-details',
  templateUrl: './med-entity-request-details.component.html',
  styleUrls: ['./med-entity-request-details.component.scss']
})
export class MedEntityRequestDetailsComponent implements OnInit {
  @Input() medEntityRequest;
  @Output() requestSolved: EventEmitter<any> = new EventEmitter();

  constructor(
    private govManagementService: GovManagementService,
    private toastService: ToastService) { }

  ngOnInit() {
  }

  public async acceptRequest() {
    console.log(this.medEntityRequest);
    this.govManagementService.acceptMedicalEntityRequest(this.medEntityRequest.identification).then(() => {
      this.requestSolved.emit(this.medEntityRequest.identification);
      this.toastService.addSuccessMessage("Medical Entity Request", "Medical Entity added successfully");
    });
  }

  public async declineRequest() {
    this.govManagementService.declineMedicalEntityRequest(this.medEntityRequest.identification).then(() => {
      this.requestSolved.emit(this.medEntityRequest.identification);
      this.toastService.addSuccessMessage("Medical Entity Request", "Medical Entity Request declined");
    });
  }

  public getEntityType(entityType) {
    return MedicalEntityType[entityType];
  }

  public getFileLink() {
    return "https://ipfs.io/ipfs/" + this.medEntityRequest.fileHash;
  }
}

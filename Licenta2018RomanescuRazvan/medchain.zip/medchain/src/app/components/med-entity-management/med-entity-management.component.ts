import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-med-entity-management',
  templateUrl: './med-entity-management.component.html',
  styleUrls: ['./med-entity-management.component.scss']
})
export class MedEntityManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}

import { Component, OnInit } from '@angular/core';
import { Web3jsService, GovManagementService } from '../../services';
import { from } from 'rxjs';

@Component({
  selector: 'app-med-entity-management',
  templateUrl: './med-entity-management.component.html',
  styleUrls: ['./med-entity-management.component.scss']
})
export class MedEntityManagementComponent implements OnInit {
  private intervalId;
  public medEntities;

  constructor(
    private web3Service: Web3jsService,
    private govManagementService: GovManagementService
  ) { }

  ngOnInit() {
    this.intervalId = setInterval(() => this.getListOfMedicalEntities(), 100);
  }

  public getListOfMedicalEntities() {
    let currentUser = this.web3Service.currentAccount;
    let observable = from(this.govManagementService.getGovMedicalEntities(currentUser));

    observable.subscribe(
      (result) => {
        this.medEntities = result;
        console.log(this.medEntities);
        clearInterval(this.intervalId);
      },
      (error) => { }
    )
  }
}

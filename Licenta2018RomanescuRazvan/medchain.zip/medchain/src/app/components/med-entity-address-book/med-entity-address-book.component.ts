import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-med-entity-address-book',
  templateUrl: './med-entity-address-book.component.html',
  styleUrls: ['./med-entity-address-book.component.scss']
})
export class MedEntityAddressBookComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

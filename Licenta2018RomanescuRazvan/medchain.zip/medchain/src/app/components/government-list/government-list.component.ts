import { Component, OnInit } from '@angular/core';
import { GovManagementService, Web3jsService } from '../../services';
import { from } from 'rxjs';

@Component({
  selector: 'app-government-list',
  templateUrl: './government-list.component.html',
  styleUrls: ['./government-list.component.scss']
})
export class GovernmentListComponent implements OnInit {
  private intervalId;
  public governments;

  constructor(private govManagementService: GovManagementService) { }

  ngOnInit() {
    this.intervalId = setInterval(() => this.getListOfGovernments(), 100);
  }
  
  public getListOfGovernments() {
    let observable = from(this.govManagementService.getGovs());

    observable.subscribe(
      (result) => {
        this.governments = result;
        clearInterval(this.intervalId);
      },
      (error) => {}
    )
  }
}

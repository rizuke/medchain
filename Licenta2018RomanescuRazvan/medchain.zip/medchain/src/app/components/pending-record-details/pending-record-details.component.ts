import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { RecordType, MedicineBranch } from '../../models';
import { HealthWalletService } from '../../services';

@Component({
  selector: 'app-pending-record-details',
  templateUrl: './pending-record-details.component.html',
  styleUrls: ['./pending-record-details.component.scss']
})
export class PendingRecordDetailsComponent implements OnInit {
  @Input() pendingRecord;
  @Output() recordSolved: EventEmitter<any> = new EventEmitter();

  recordDescription: string;

  constructor(
    private healthWallet: HealthWalletService
  ) { }

  ngOnInit() {
    this.recordDescription = this.pendingRecord.recordDescription;
  }

  public getRecordType() {
    return RecordType[parseInt(this.pendingRecord.recordType)];
  }

  public getMedicineBranch() {
    return MedicineBranch[parseInt(this.pendingRecord.medicineBranch)];
  }

  public getFileLink() {
    return "https://ipfs.io/ipfs/" + this.pendingRecord.fileHash;
  }

  public async acceptRecord() {
    await this.healthWallet.addRecordFromPatientQueueToHistory(this.pendingRecord.patient, this.pendingRecord.id);

    this.recordSolved.emit(this.pendingRecord.id);
  }

  public declineRecord() {
    this.healthWallet.addRecordFromPatientQueueToMedEntityQueue(this.pendingRecord.patient, this.pendingRecord.medicalEntity, this.pendingRecord.id, "");
  }
}

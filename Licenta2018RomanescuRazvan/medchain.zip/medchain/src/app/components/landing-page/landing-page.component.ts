import { Component, OnInit } from '@angular/core';
import { UserService, Web3jsService } from '../../services';
import { from } from 'rxjs';
import { UserType } from '../../models';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss']
})
export class LandingPageComponent implements OnInit {
  private intervalId;
  public userAccount;
  public userStatus;

  constructor(private web3Service: Web3jsService, private userService: UserService) { }

  ngOnInit() {
    this.intervalId = setInterval(() => this.getLandingPageDetails(), 300);
  }

  public getLandingPageDetails() {
    let observable = from(this.userService.getUserTypeForCurrentUser());

    observable.subscribe(
      (result) => {
        this.userStatus = UserType[result];
        this.userAccount = this.web3Service.currentAccount;
      },
      (error) => {}
    )
  }
  ngOnDestroy() {
    clearInterval(this.intervalId);
  }
}

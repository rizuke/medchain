import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-patient-med-entity-details',
  templateUrl: './patient-med-entity-details.component.html',
  styleUrls: ['./patient-med-entity-details.component.scss']
})
export class PatientMedEntityDetailsComponent implements OnInit {
  @Input() medEntity;

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import { GovManagementService, ToastService } from '../../services';

@Component({
  selector: 'app-add-gov',
  templateUrl: './add-gov.component.html',
  styleUrls: ['./add-gov.component.scss']
})
export class AddGovComponent implements OnInit {
  constructor(
    private govManagementService: GovManagementService,
    private toastService: ToastService) { }

  ngOnInit() {
  }

  public addGovernment(govAddress: string, selectedCountry: string) {
    this.govManagementService.addGovernment(govAddress, selectedCountry);
  }
}

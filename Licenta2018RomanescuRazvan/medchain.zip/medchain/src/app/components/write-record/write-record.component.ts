import { Component, OnInit, OnDestroy } from '@angular/core';
import { SelectItem, MenuItem } from 'primeng/api';
import { Buffer } from 'buffer';
import { HealthWalletService, EncryptionService, AddressBookService, ToastService, Web3jsService, IpfsService } from '../../services';

@Component({
  selector: 'app-write-record',
  templateUrl: './write-record.component.html',
  styleUrls: ['./write-record.component.scss']
})
export class WriteRecordComponent implements OnInit {
  public patientRecords;
  public intervalId;

  public countryId;
  public medCountryId;

  public identificationChecked: boolean = false;
  public patientDetails;
  public processedFile;

  public isUrgency: boolean;
  public isDiagnostic: boolean;
  public selectedRecordType;
  public selectedMedicineBranch;
  public addedDate: Date;
  public recordName: string;
  public recordDescription: string;
  public medicalEntityName: string;
  public rootId: number;
  public fileHash: string;

  public recordTypes: SelectItem[] = [
    { label: "Regular Check", value: "0" },
    { label: "Diagnostic", value: "1" },
    { label: "Treatment", value: "2" },
    { label: "Prescription", value: "3" },
    { label: "Hospitalization", value: "4" },
    { label: "Vaccination", value: "5" },
    { label: "Surgery", value: "6" },
    { label: "Prosthetics", value: "7" },
    { label: "Transplants", value: "8" },
    { label: "Record Correction", value: "9" },
    { label: "Others", value: "10" },
  ];

  public medicineBranches: SelectItem[] = [
    { label: "General", value: "0" },
    { label: "Cardiology", value: "1" },
    { label: "Dentistry", value: "2" },
    { label: "Endocrinology", value: "2" },
    { label: "Gastroenterology", value: "2" },
    { label: "Hematology", value: "2" },
    { label: "Kinetotherapy", value: "2" },
    { label: "Work Medicine", value: "2" },
    { label: "Neurosurgery", value: "2" },
    { label: "Neurology", value: "2" },
    { label: "Pediatric Neurology", value: "2" },
    { label: "Ginecology", value: "2" },
    { label: "Ophtalmology", value: "2" },
    { label: "Oncology", value: "2" },
    { label: "ORL", value: "2" },
    { label: "PediatricOrtopedy", value: "2" },
    { label: "Pneumology", value: "2" },
    { label: "Psychology", value: "2" },
    { label: "Radiology", value: "2" },
    { label: "Rheumatology", value: "2" },
    { label: "Hospitalization", value: "2" },
    { label: "Urology", value: "2" },
    { label: "Other", value: "2" },
  ]

  public items: MenuItem[];

  activeIndex: number = 0;

  constructor(
    private web3Service: Web3jsService,
    private addressBookService: AddressBookService,
    private healthWalletService: HealthWalletService,
    private encryptionService: EncryptionService,
    private ipfsService: IpfsService,
    private toastService: ToastService
  ) {
    this.isUrgency = false;
    this.isDiagnostic = false;
    this.fileHash = "";
  }

  ngOnInit() {
    this.items = [{
      label: 'Basics',
      command: (event: any) => {
        this.activeIndex = 0;
        console.log(this.activeIndex);
      }
    },
    {
      label: 'Categories',
      command: (event: any) => {
        this.activeIndex = 1;
        console.log(this.activeIndex);
      }
    },
    {
      label: 'Record Details',
      command: (event: any) => {
        this.activeIndex = 2;
        console.log(this.activeIndex);
      }
    },
    {
      label: 'Files & Linkage',
      command: (event: any) => {
        this.activeIndex = 3;
        console.log(this.activeIndex);
      }
    }
    ];
  }

  public async writeRecord() {
    if (this.isUrgency == null || this.isDiagnostic == null || this.selectedRecordType == null || this.selectedMedicineBranch == null || this.recordName == null || this.recordDescription == null || this.rootId == null) {
      this.toastService.addErrorMessage("Write Record", "Validation errors in the form");
    }
    else {
      let currentUser = this.web3Service.currentAccount;

      let key = this.countryId + this.medCountryId;
      let encRecordName = this.encryptionService.encrypt(key, this.recordName);
      let encRecordDescription = this.encryptionService.encrypt(key, this.recordDescription);
      let encMedicalEntityName = this.encryptionService.encrypt(key, this.medicalEntityName);
      let encfileHash = this.encryptionService.encrypt(key, this.fileHash);

      await this.ipfsService.ipfsObject.add(this.processedFile, (error, result) => {
        if (error) {
          console.log(error);
          return;
        }

        this.fileHash = result[0].hash;
        console.log(this.fileHash);

        this.healthWalletService.addRecordToPatientQueue(this.isUrgency, parseInt(this.selectedRecordType), parseInt(this.selectedMedicineBranch), Math.round(Date.now() / 1000), this.recordName, this.recordDescription, this.medicalEntityName, this.patientDetails.identification, currentUser, this.fileHash, this.rootId.toString());
        // this.healthWalletService.addRecordToPatientQueue(this.isUrgency, parseInt(this.selectedRecordType), parseInt(this.selectedMedicineBranch), Math.round(Date.now() / 1000), encRecordName, encRecordDescription, encMedicalEntityName, this.patientDetails.identification, currentUser, encfileHash, this.rootId.toString());
        this.setFormDefaultValues();
        this.toastService.addSuccessMessage("Write Record", "Record added successfully to patient's queue");
      });
    }
  }

  public handleFileUpload(event) {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.readAsArrayBuffer(file);
    reader.onloadend = () => {
      this.processedFile = new Buffer(<string>reader.result);
    }
  }

  public async handleCheckIdentification() {
    let identification = this.countryId + this.medCountryId;

    let encIdentification = this.encryptionService.encrypt(identification, identification);

    let response = await this.addressBookService.checkIfPatientIdentificationExists(encIdentification);

    if (response) {
      let patientAddress = await this.addressBookService.getPatientAddressGivenIdentification(encIdentification);
      this.patientDetails = await this.addressBookService.getPatientDetails(patientAddress);

      let currentUser = this.web3Service.currentAccount;
      let isMedEntityAssociatedWithPatient = await this.addressBookService.checkIfPatientIsAssociatedToMedEntity(patientAddress, currentUser);

      if (!isMedEntityAssociatedWithPatient) {
        this.identificationChecked = false;
        this.toastService.addErrorMessage("Identification Check", "The patient is not associated with you");
      }
      else {
        this.identificationChecked = true;
        this.toastService.addSuccessMessage("Identification Check", "Patient found successfully");
      }
    }
    else {
      this.identificationChecked = false;
      this.toastService.addErrorMessage("Identification Check", "There was no patient found");
    }
  }

  private setFormDefaultValues() {
    this.isUrgency = false;
    this.isDiagnostic = false;
    this.selectedRecordType = null;
    this.selectedMedicineBranch = null;
    this.recordName = null;
    this.medicalEntityName = null;
    this.recordDescription = null;
    this.rootId = null;
    this.processedFile = null;
    this.fileHash = null;

    this.activeIndex = 0;
  }

  public getPatientBirthdate() {
    return new Date(this.patientDetails.birthDate * 1000).toLocaleDateString("RO-RO");
  }
}

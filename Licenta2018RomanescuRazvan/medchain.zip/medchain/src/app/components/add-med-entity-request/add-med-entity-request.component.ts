import { Component, OnInit } from '@angular/core';
import { Web3jsService, AddressBookService } from '../../services';

@Component({
  selector: 'app-add-med-entity-request',
  templateUrl: './add-med-entity-request.component.html',
  styleUrls: ['./add-med-entity-request.component.scss']
})
export class AddMedEntityRequestComponent implements OnInit {
  public medEntityAddress: string;

  constructor(
    private web3Service: Web3jsService,
    private addressBookService: AddressBookService
  ) { }

  ngOnInit() {
  }

  public addPatientRequestToMedEntity() {
    let currentUser = this.web3Service.currentAccount;

    this.addressBookService.addPatientRequestToMedicalEntity(currentUser, this.medEntityAddress);
  }
}

import { Component, OnInit } from '@angular/core';
import { Buffer } from 'buffer';
import { MedicalEntityType } from '../../models';
import { Web3jsService, GovManagementService, IpfsService } from '../../services';

@Component({
  selector: 'app-add-med-entity',
  templateUrl: './add-med-entity.component.html',
  styleUrls: ['./add-med-entity.component.scss']
})
export class AddMedEntityComponent implements OnInit {
  public processedFile;

  public identification: string;
  public name: string;
  public establishmentAddress: string;
  public entityType: string;
  public isActive: boolean;
  public begunActivity: Date;
  public fileHash: string;

  constructor(
    private web3Service: Web3jsService,
    private govManagementService: GovManagementService,
    private ipfsService: IpfsService
  ) { }

  ngOnInit() {
  }

  public handleFileUpload(event) {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.readAsArrayBuffer(file);
    reader.onloadend = () => {
      this.processedFile = new Buffer(<string>reader.result);
    }
  }

  public async addMedicalEntity() {
    let medEntityType = MedicalEntityType.Individual;
    if (this.entityType == '0') {
      medEntityType = MedicalEntityType.Individual;
    }
    else if (this.entityType == '1') {
      medEntityType = MedicalEntityType.PublicHospital;
    }
    else if (this.entityType == '2') {
      medEntityType = MedicalEntityType.PrivateHospital;
    }

    await this.ipfsService.ipfsObject.add(this.processedFile, (error, result) => {
      if (error) {
        console.log(error);
        return;
      }

      this.fileHash = result[0].hash;

      this.govManagementService.addFileHashToMedicalEntity(this.identification, this.fileHash);
      this.govManagementService.addMedicalEntity(this.identification, medEntityType, this.isActive, this.begunActivity.getTime() / 1000, 0, this.name, this.establishmentAddress).then(() => {
        this.cleanInputs();
      });
    });
  }

  public cleanInputs() {
    this.identification = null;
    this.name = null;
    this.establishmentAddress = null;
    this.entityType = null;
    this.isActive = false;
    this.begunActivity = null;
    this.processedFile = null;
  }
}

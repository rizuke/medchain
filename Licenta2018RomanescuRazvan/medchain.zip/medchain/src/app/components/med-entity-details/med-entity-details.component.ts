import { Component, OnInit, Input } from '@angular/core';
import { MedicalEntityType } from '../../models';
import { Web3jsService, GovManagementService } from '../../services';

@Component({
  selector: 'app-med-entity-details',
  templateUrl: './med-entity-details.component.html',
  styleUrls: ['./med-entity-details.component.scss']
})
export class MedEntityDetailsComponent implements OnInit {
  @Input() medEntity;

  constructor(
    private web3Service: Web3jsService,
    private govManagementService: GovManagementService
  ) { }

  ngOnInit() {
  }

  public getEntityType() {
    return MedicalEntityType[this.medEntity.entityType];
  }

  public getBegunActivityDate() {
    return new Date(parseInt(this.medEntity.begunActivity) * 1000).toLocaleDateString("RO-RO");
  }

  public getSuspendedActivityDate() {
    return new Date(parseInt(this.medEntity.suspendMedEntity) * 1000).toLocaleDateString("RO-RO");
  }

  public getFilesLink() {
    return "https://ipfs.io/ipfs/" + this.medEntity.fileHash;
  }

  public async suspendMedEntity() {
    this.medEntity.isActive = false;
    await this.govManagementService.suspendMedicalEntityActivity(this.medEntity.identification, Math.round(new Date().getTime() / 1000));
  }

  public async activateMedEntity() {
    this.medEntity.isActive = true;
    await this.govManagementService.beginMedicalEntityActivity(this.medEntity.identification, Math.round(new Date().getTime() / 1000));
  }
}

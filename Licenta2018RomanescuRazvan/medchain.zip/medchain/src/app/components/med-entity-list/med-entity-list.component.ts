import { Component, OnInit } from '@angular/core';
import { Web3jsService, AddressBookService } from '../../services';
import { from } from 'rxjs';

@Component({
  selector: 'app-med-entity-list',
  templateUrl: './med-entity-list.component.html',
  styleUrls: ['./med-entity-list.component.scss']
})
export class MedEntityListComponent implements OnInit {
  private intervalId;
  public medEntities;

  constructor(
    private web3Service: Web3jsService,
    private addressBookService: AddressBookService
  ) { }

  ngOnInit() {
    this.intervalId = setInterval(() => this.getMedEntities(), 100);
  }

  public getMedEntities() {
    let currentUser = this.web3Service.currentAccount;
    let observable = from(this.addressBookService.getMedEntities(currentUser));

    observable.subscribe(
      (result) => {
        this.medEntities = result;
        console.log(result);
        clearInterval(this.intervalId);
      },
      (error) => { }
    )
  }
}

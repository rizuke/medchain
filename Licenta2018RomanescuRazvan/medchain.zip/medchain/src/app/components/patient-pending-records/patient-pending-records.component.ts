import { Component, OnInit } from '@angular/core';
import { Web3jsService, HealthWalletService } from '../../services';
import { from } from 'rxjs';

@Component({
  selector: 'app-patient-pending-records',
  templateUrl: './patient-pending-records.component.html',
  styleUrls: ['./patient-pending-records.component.scss']
})
export class PatientPendingRecordsComponent implements OnInit {
  public pendingRecords;
  private intervalId;

  constructor(
    private web3Service: Web3jsService,
    private healthWalletService: HealthWalletService
  ) { }

  ngOnInit() {
    this.intervalId = setInterval(() => this.getPendingRecords(), 100);
  }

  public getPendingRecords() {
    let currentUser = this.web3Service.currentAccount;
    let observable = from(this.healthWalletService.getPatientPendingRecords(currentUser));
    
    observable.subscribe(
      (result) => {
        this.pendingRecords = result;
        console.log(result);
        clearInterval(this.intervalId);
      },
      (error) => { }
    )
  }
  
  public handleRecordSolved(event) {
    this.pendingRecords = this.pendingRecords.filter(r => r.id != event);
  }
}

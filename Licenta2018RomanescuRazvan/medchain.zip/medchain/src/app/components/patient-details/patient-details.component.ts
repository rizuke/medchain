import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Web3jsService, AddressBookService } from '../../services';

@Component({
  selector: 'app-patient-details',
  templateUrl: './patient-details.component.html',
  styleUrls: ['./patient-details.component.scss']
})
export class PatientDetailsComponent implements OnInit {
  @Input() patientDetails;
  @Output() patientRemoved: EventEmitter<any> = new EventEmitter();

  constructor(
    private web3Service: Web3jsService,
    private addressBookService: AddressBookService
  ) { }

  ngOnInit() {
  }

  public getBirthdate() {
    return new Date(parseInt(this.patientDetails.birthDate) * 1000).toLocaleDateString("RO-RO");
  }

  public removeAffiliation() {
    let currentUser = this.web3Service.currentAccount;
    this.addressBookService.removePatientFromMedicalEntity(this.patientDetails.identification, currentUser, "");

    this.patientRemoved.emit(this.patientDetails.identification);
  }
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-address-book',
  templateUrl: './patient-address-book.component.html',
  styleUrls: ['./patient-address-book.component.scss']
})
export class PatientAddressBookComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

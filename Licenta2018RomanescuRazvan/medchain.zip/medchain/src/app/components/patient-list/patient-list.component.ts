import { Component, OnInit } from '@angular/core';
import { from } from 'rxjs';
import { Web3jsService, AddressBookService } from '../../services';

@Component({
  selector: 'app-patient-list',
  templateUrl: './patient-list.component.html',
  styleUrls: ['./patient-list.component.scss']
})
export class PatientListComponent implements OnInit {
  private intervalId;
  public patients;

  constructor(
    private web3Service: Web3jsService,
    private addressBookService: AddressBookService
  ) { }

  ngOnInit() {
    this.intervalId = setInterval(() => this.getPatients(), 100);
  }

  public getPatients() {
    let currentUser = this.web3Service.currentAccount;
    let observable = from(this.addressBookService.getPatients(currentUser));
    
    observable.subscribe(
      (result) => {
        this.patients = result;
        console.log(result);
        clearInterval(this.intervalId);
      },
      (error) => { }
    )
  }

  public handlePatientRemoved(event) {
    this.patients = this.patients.filter(p => p.identification != event);
  }
}

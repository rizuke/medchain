import { Component, OnInit, Input } from '@angular/core';
import { RecordType, MedicineBranch } from '../../models';

@Component({
  selector: 'app-record-details',
  templateUrl: './record-details.component.html',
  styleUrls: ['./record-details.component.scss']
})
export class RecordDetailsComponent implements OnInit {
  @Input() record;
  public recordDescription;

  constructor() { }

  ngOnInit() {
    this.recordDescription = this.record.recordDescription;
  }

  public getRecordType() {
    return RecordType[parseInt(this.record.recordType)];
  }

  public getMedicineBranch() {
    return MedicineBranch[parseInt(this.record.medicineBranch)];
  }

  public getFileLink() {
    return "https://ipfs.io/ipfs/" + this.record.fileHash;
  }

  public getAddedDate() {
    return new Date(this.record.addedDate * 1000).toLocaleDateString("RO-RO");
  }
}

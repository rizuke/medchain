// Common
export * from './landing-page/landing-page.component';
export * from './side-menu-items/side-menu-items.component';
export * from './pending/pending.component';
export * from './not-found/not-found.component';


export * from './address-book/address-book.component';
export * from './profile/profile.component';

// Authority & Government related components
export * from './government-management/government-management.component';
export * from './government-list/government-list.component';
export * from './add-gov/add-gov.component';
export * from './government-details/government-details.component';

// Med Entities components
export * from './med-entity-management/med-entity-management.component';
export * from './med-entity-requests/med-entity-requests.component';
export * from './med-entity-request-details/med-entity-request-details.component';

// Register components
export * from './register-patient/register-patient.component';
export * from './register-med/register-med.component';

// Common
export * from './landing-page/landing-page.component';
export * from './side-menu-items/side-menu-items.component';
export * from './not-found/not-found.component';

export * from './profile/profile.component';

// Authority & Government related components
export * from './government-management/government-management.component';
export * from './government-list/government-list.component';
export * from './add-gov/add-gov.component';
export * from './government-details/government-details.component';

// Med Entities components
export * from './med-entity-management/med-entity-management.component';
export * from './add-med-entity/add-med-entity.component';
export * from './med-entity-requests/med-entity-requests.component';
export * from './med-entity-request-details/med-entity-request-details.component';
export * from './med-entity-details/med-entity-details.component';
export * from './med-entity-address-book/med-entity-address-book.component';
export * from './write-record/write-record.component';
export * from './med-pending-records/med-pending-records.component';
export * from './editable-pending-record-details/editable-pending-record-details.component';
export * from './med-patient-record-history/med-patient-record-history.component';

// Patient components
export * from './patient-requests/patient-requests.component';
export * from './patient-details/patient-details.component';
export * from './patient-request-details/patient-request-details.component';
export * from './patient-list/patient-list.component';
export * from './patient-address-book/patient-address-book.component';
export * from './add-med-entity-request/add-med-entity-request.component';
export * from './med-entity-list/med-entity-list.component';
export * from './patient-med-entity-details/patient-med-entity-details.component';
export * from './patient-pending-records/patient-pending-records.component';
export * from './pending-record-details/pending-record-details.component';
export * from './patient-record-history/patient-record-history.component';
export * from './record-details/record-details.component';

// Register components
export * from './register-patient/register-patient.component';
export * from './register-med/register-med.component';

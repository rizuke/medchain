import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-government-details',
  templateUrl: './government-details.component.html',
  styleUrls: ['./government-details.component.scss']
})
export class GovernmentDetailsComponent implements OnInit {
  @Input() gov;
  
  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Web3jsService, AddressBookService } from '../../services';

@Component({
  selector: 'app-patient-request-details',
  templateUrl: './patient-request-details.component.html',
  styleUrls: ['./patient-request-details.component.scss']
})
export class PatientRequestDetailsComponent implements OnInit {
  @Input() patientRequestDetails;
  @Output() requestSolved: EventEmitter<any> = new EventEmitter();

  constructor(
    private web3Service: Web3jsService,
    private addressBookService: AddressBookService
  ) { }

  ngOnInit() {
  }

  public acceptRequest() {
    let currentUser = this.web3Service.currentAccount;
    this.addressBookService.acceptPatientRequestToMedicalEntity(this.patientRequestDetails.identification, currentUser).then(() => {
      this.requestSolved.emit(this.patientRequestDetails.identification);
    });
  }

  public declineRequest() {
    let currentUser = this.web3Service.currentAccount;
    this.addressBookService.declinePatientRequestToMedicalEntity(this.patientRequestDetails.identification, currentUser, "").then(() => {
      this.requestSolved.emit(this.patientRequestDetails.identification);
    });
  }

  public getBirthdate() {
    return new Date(parseInt(this.patientRequestDetails.birthDate) * 1000).toLocaleDateString("RO-RO");
  }
}

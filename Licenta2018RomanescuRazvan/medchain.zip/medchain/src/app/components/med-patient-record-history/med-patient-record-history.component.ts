import { Component, OnInit, OnDestroy } from '@angular/core';
import { AddressBookService, HealthWalletService, EncryptionService, Web3jsService, ToastService } from '../../services';
import { SelectItem } from 'primeng/api';
import { from } from 'rxjs';

@Component({
  selector: 'app-med-patient-record-history',
  templateUrl: './med-patient-record-history.component.html',
  styleUrls: ['./med-patient-record-history.component.scss']
})
export class MedPatientRecordHistoryComponent implements OnInit, OnDestroy {
  public countryId;
  public medCountryId;

  public identificationChecked: boolean = false;
  public patientDetails;

  public onlyUrgency: boolean = true;

  public records;
  private intervalId;

  sortOptions: SelectItem[];
  sortKey: string;
  sortField: string;
  sortOrder: number;

  filterOptions: SelectItem[];
  filterKey: string = "id";

  constructor(
    private web3Service: Web3jsService,
    private addressBookService: AddressBookService,
    private healthWalletService: HealthWalletService,
    private encryptionService: EncryptionService,
    private toastService: ToastService
  ) { }

  ngOnInit() {
    this.sortOptions = [
      { label: 'Newest First', value: '!id' },
      { label: 'Oldest First', value: 'id' }
    ];

    this.filterOptions = [
      { label: "Id", value: "id" },
      { label: "Record Type", value: "recordType" },
      { label: "Medicine Branch", value: "medicineBranch" },
      { label: "Record Name", value: "recordName" },
      { label: "Medical Entity Name", value: "medicalEntityName" },
      { label: "Medical Entity Address", value: "medicalEntity" },
    ]
  }

  public async handleCheckIdentification() {
    let identification = this.countryId + this.medCountryId;

    let encIdentification = this.encryptionService.encrypt(identification, identification);

    let response = await this.addressBookService.checkIfPatientIdentificationExists(encIdentification);

    let patientAddress = await this.addressBookService.getPatientAddressGivenIdentification(encIdentification);
    this.patientDetails = await this.addressBookService.getPatientDetails(patientAddress);

    if (response) {
      let currentUser = this.web3Service.currentAccount;
      let isMedEntityAssociatedWithPatient = await this.addressBookService.checkIfPatientIsAssociatedToMedEntity(patientAddress, currentUser);

      if (this.onlyUrgency) {
        this.identificationChecked = true;
        this.toastService.addSuccessMessage("Identification Check", "Patient found successfully");

        this.intervalId = setInterval(() => this.getUrgencyOnlyRecords(), 200);
      }
      else {
        if (!isMedEntityAssociatedWithPatient) {
          this.identificationChecked = false;
          this.toastService.addErrorMessage("Identification Check", "The patient is not associated with you");
        }
        else {
          this.identificationChecked = true;
          this.intervalId = setInterval(() => this.getRecords(), 200);
          this.toastService.addSuccessMessage("Identification Check", "Patient found successfully");
        }
      }

      console.log(this.patientDetails);
    }
    else {
      this.identificationChecked = false;
      this.toastService.addErrorMessage("Identification Check", "There was no patient found");
    }
  }

  public getRecords() {
    let observable = from(this.healthWalletService.getRecords(this.patientDetails.identification));

    observable.subscribe(
      (result) => {
        this.records = result;
        console.log(this.records);
        clearInterval(this.intervalId);
      },
      (error) => { }
    )
  }

  public getUrgencyOnlyRecords() {
    let observable = from(this.healthWalletService.getUrgencyOnlyRecords(this.patientDetails.identification));

    observable.subscribe(
      (result) => {
        this.records = result;
        console.log(this.records);
        clearInterval(this.intervalId);
      },
      (error) => { }
    )
  }

  onSortChange(event) {
    let value = event.value;

    if (value.indexOf('!') === 0) {
      this.sortOrder = -1;
      this.sortField = value.substring(1, value.length);
    }
    else {
      this.sortOrder = 1;
      this.sortField = value;
    }

    console.log(this.filterKey);
  }

  ngOnDestroy() {
    clearInterval(this.intervalId);
  }
}

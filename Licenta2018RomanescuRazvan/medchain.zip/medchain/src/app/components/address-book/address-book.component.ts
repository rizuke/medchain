import { Component, OnInit } from '@angular/core';
import { UserService, ToastService, EncryptionService, AddressBookService } from '../../services';
import { UserType } from './../../models';

@Component({
  selector: 'app-address-book',
  templateUrl: './address-book.component.html',
  styleUrls: ['./address-book.component.scss']
})
export class AddressBookComponent implements OnInit {

  constructor(
    private userService: UserService,
    private addressBookService: AddressBookService,
    private encryptionService: EncryptionService,
    private toastService: ToastService) { }

  ngOnInit() {
  }

  public async registerPatient() {
    this.addressBookService.addPatientDetails("0x9b78A3b5a417EA3389257f820F4df8e507C0d599", "Razvan", "Romanescu", 161, "Iasi, Romania", "0x3660adf2346bD21eeC895FF27Fc71eDD75586e76");
  }

  public async getPatientDetails() {
    this.addressBookService.getPatientDetails("0x9b78A3b5a417EA3389257f820F4df8e507C0d599");
  }

  public async acceptPatientRequest() {
    this.addressBookService.acceptPatientRequestToMedicalEntity("0x9b78A3b5a417EA3389257f820F4df8e507C0d599", "0x3660adf2346bD21eeC895FF27Fc71eDD75586e76");
  }

  public async getUserType() {
    let userType = await this.userService.getUserTypeForCurrentUser();

    this.toastService.addInfoMessage("UserType Info", "UserType: " + UserType[userType]);
    console.log(userType);
    return userType;
  }
}

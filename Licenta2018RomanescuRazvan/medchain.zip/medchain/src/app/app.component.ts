import { Component } from '@angular/core';
import { Web3jsService, UserService } from './services';
import { NbSidebarService, NbMenuItem } from '@nebular/theme';
import { faUser, faPowerOff } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  public isLandingPage: boolean;
  public isRegisterPage: boolean;

  faUser = faUser;
  faPowerOff = faPowerOff;

  constructor(
    private webService: Web3jsService,
    private sidebarService: NbSidebarService) {
    this.isLandingPage = true;
    this.isRegisterPage = false;
  }

  public toggle() {
    this.sidebarService.toggle(true);
  }

  public handleLandingPage() {
    this.isLandingPage = false;
  }

  public handlePatientRegister() {
    this.isLandingPage = false;
    this.isRegisterPage = true;
  }

  public handleMedicalEntityRegister() {
    this.isLandingPage = false;
    this.isRegisterPage = true;
  }

  public handleSignOut() {
    this.isLandingPage = true;
  }
}

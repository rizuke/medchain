import { Component, OnInit } from '@angular/core';
import { Web3jsService, UserService, ToastService } from './services';
import { NbSidebarService, NbMenuItem } from '@nebular/theme';
import { faUser, faPowerOff } from '@fortawesome/free-solid-svg-icons';
import { UserType } from './models';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  public isLandingPage: boolean;
  public isRegisterPage: boolean;

  faUser = faUser;
  faPowerOff = faPowerOff;

  constructor(
    private webService: Web3jsService,
    private userService: UserService,
    private toastService: ToastService,
    private sidebarService: NbSidebarService) {
  }

  ngOnInit() {
    this.isLandingPage = true;
    this.isRegisterPage = false;
  }

  public toggle() {
    this.sidebarService.toggle(true);
  }

  public async handleLandingPage() {
    let userStatus = await this.userService.getUserTypeForCurrentUser();

    if (userStatus == UserType.Pending || userStatus == UserType.Suspended) {
      this.toastService.addInfoMessage("Status", "You cannot enter in the app in a pending state");
    }
    else if (userStatus == UserType.Unregistered) {
      this.toastService.addInfoMessage("Status", "You cannot enter in the app unregistered");
    }
    else {
      this.isLandingPage = false;
    }
  }

  public async handlePatientRegister() {
    let userStatus = await this.userService.getUserTypeForCurrentUser();

    if (userStatus == UserType.Pending || userStatus == UserType.Suspended) {
      this.toastService.addInfoMessage("Status", "You cannot register in a pending state");
    }
    else if (userStatus == UserType.Unregistered) {
      this.isLandingPage = false;
      this.isRegisterPage = true;
    }
    else {
      this.toastService.addInfoMessage("Status", "You cannot register again given your account status");
    }
  }

  public async handleMedicalEntityRegister() {
    let userStatus = await this.userService.getUserTypeForCurrentUser();

    if (userStatus == UserType.Pending || userStatus == UserType.Suspended) {
      this.toastService.addInfoMessage("Status", "You cannot register in a pending state");
    }
    else if (userStatus == UserType.Unregistered) {
      this.isLandingPage = false;
      this.isRegisterPage = true;
    }
    else {
      this.toastService.addInfoMessage("Status", "You cannot register again given your account status");
    }
  }

  public handleSignOut() {
    this.isLandingPage = true;
  }
}

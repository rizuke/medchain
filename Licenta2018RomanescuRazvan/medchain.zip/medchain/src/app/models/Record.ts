import { RecordType } from './enums/RecordTypeEnum';
import { MedicineBranch } from './enums/MedicineBranchEnum';

export interface Record {
    id: string;

    recordType: RecordType;
    medicineBranch: MedicineBranch;
    addedDate: number;

    recordName: string;
    recordDescription: string;
    medicalEntityName: string;

    patient: string;
    medicalEntity: string;

    fileHash: string;

    rootId: string;
}

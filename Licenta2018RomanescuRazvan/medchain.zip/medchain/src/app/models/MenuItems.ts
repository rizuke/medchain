import { NbMenuItem } from '@nebular/theme';

export const patientNavItems: NbMenuItem[] = [
    { title: 'Address Book', link: 'patient/addressbook', icon: '' },
    { title: 'Pending Records', link: 'patient/pending', icon: '' },
    { title: 'Record History', link: 'patient/history', icon: '' },
]

export const medEntityNavItems: NbMenuItem[] = [
    { title: 'Address Book', link: 'med/addressbook', icon: '' },
    { title: 'Pending Records', link: 'med/pending', icon: '' },
    { title: 'Write Record', link: 'med/write', icon: '' },
    { title: 'View Patient History', link: 'med/patienthistory', icon: '' },
]

export const govNavItems: NbMenuItem[] = [
    { title: 'Requests', link: '/gov/requests', icon: '' },
    { title: 'Add Medical Entity', link: '/gov/addmed', icon: '' },
    { title: 'Medical Entities Management', link: '/gov/medentities', icon: '' }
]

export const authorityNavItems = [
    { title: 'Government Management', link: 'authority/management', icon: '' },
    { title: 'View Governments', link: 'authority/govs', icon: '' }
]

import { NbMenuItem } from '@nebular/theme';

export const patientNavItems: NbMenuItem[] = [
    { title: 'Profile', link: 'patient/profile', icon: '' },
    { title: 'Address Book', link: 'patient/addressbook', icon: '' },
    { title: 'Pending Records', link: '.', icon: '' },
    { title: 'Record History', link: '.', icon: '' },
]

export const medEntityNavItems: NbMenuItem[] = [
    { title: 'Profile', link: 'med/profile', icon: '' },
    { title: 'Address Book', link: 'med/addressbook', icon: '' },
    { title: 'Pending Records', link: '.', icon: '' },
    { title: 'Write Record', link: '.', icon: '' },
]

export const govNavItems: NbMenuItem[] = [
    { title: 'Profile', link: '/gov/profile', icon: '' },
    { title: 'Requests', link: '/gov/requests', icon: '' },
    { title: 'Medical Entities Management', link: '/gov/medentities', icon: '' }
]

export const authorityNavItems = [
    { title: 'Government Management', link: 'authority/management', icon: 'pi pi-check' },
    { title: 'View Governments', link: 'authority/govs', icon: '' }
]

export enum DiagnosticType { InfectiousDisease, HematologicalDisease, ChronicDisease, Allergies }

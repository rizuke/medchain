export enum MenuType { Patient, MedicalEntity, Government, Authority };

export enum RecordType { RoutineCheck, Diagnostic, Treatment, Prescription, Hospitalization, Surgery, Prosthetics, Transplants, Correction, Other }

export enum RecordType { RoutineCheck, Diagnostic, Treatment, Prescription, Hospitalization, Vaccination, Surgery, Prosthetics, Transplants, Correction, Other }

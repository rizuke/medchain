export enum UserType { Patient, MedicalEntity, Government, Authority, Pending, Unregistered }

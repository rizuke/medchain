export enum MedicalEntityType { Individual, PublicHospital, PrivateHospital }

export interface Government {
    identification: string;
    country: string;
    numberOfMedicalEntities: number;
}

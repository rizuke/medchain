import { MedicalEntityType } from './enums/MedicalEntityTypeEnum';

export interface MedicalEntity {
    identification: string;
    govIdentification: string;
    entityType: MedicalEntityType;

    isActive: boolean;
    begunActivity: number;
    suspendedActivitiy: number;

    name: string;
    establishmentAddress: string;
}

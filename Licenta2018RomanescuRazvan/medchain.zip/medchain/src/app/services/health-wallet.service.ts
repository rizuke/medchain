import { Injectable } from '@angular/core';
import { Web3jsService } from './web3js.service';
import { RecordType, MedicineBranch, DiagnosticType } from '../models';

@Injectable({
  providedIn: 'root'
})
export class HealthWalletService {

  constructor(private web3Service: Web3jsService) { }

  // Contract-level methods

  public async addRecordToPatientQueue(isForUrgency: boolean, recordType: RecordType, medicineBranch: MedicineBranch, addedDate: number, recordName: string, recordDescription: string, medicalEntityName: string, patient: string, medicalEntity: string, fileHash: string, rootId: string) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    healthWalletInstance.methods.addRecordToPatientQueue(isForUrgency, recordType, medicineBranch, addedDate, recordName, recordDescription, medicalEntityName, patient, medicalEntity, fileHash, rootId).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async addRecordToPatientQueueWithDiagnosticTrack(isForUrgency: boolean, recordType: RecordType, medicineBranch: MedicineBranch, diagnosticType: DiagnosticType, addedDate: number, recordName: string, recordDescription: string, medicalEntityName: string, patient: string, medicalEntity: string, fileHash: string, rootId: string) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    healthWalletInstance.methods.addRecordToPatientQueue(isForUrgency, recordType, medicineBranch, diagnosticType, addedDate, recordName, recordDescription, medicalEntityName, patient, medicalEntity, fileHash, rootId).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async addRecordFromPatientQueueToHistory(patientAddress: string, recordId: number) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    healthWalletInstance.methods.addRecordFromPatientQueueToHistory(patientAddress, recordId).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async addRecordFromPatientQueueToMedEntityQueue(patient: string, medEntity: string, recordId: number, declineReason: string) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    healthWalletInstance.methods.addRecordFromPatientQueueToMedEntityQueue(patient, medEntity, recordId, declineReason).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async addRecordFromMedEntityQueueToPatientHistoryDirectly(patient: string, medEntity: string, recordId: number) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    healthWalletInstance.methods.addRecordFromMedEntityQueueToPatientHistoryDirectly(patient, medEntity, recordId).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async editRecordFromMedEntityQueue(recordId: number, isForUrgency: boolean, recordType: RecordType, medicineBranch: MedicineBranch, addedDate: number, recordName: string, recordDescription: string, medicalEntityName: string, medicalEntity: string, fileHash: string, rootId: number) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    healthWalletInstance.methods.editRecordFromMedEntityQueue(recordId, isForUrgency, recordType, medicineBranch, addedDate, recordName, recordDescription, medicalEntityName, medicalEntity, fileHash, rootId).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async getRecordDetails(recordId: number) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let record = await healthWalletInstance.methods.getRecordDetails(recordId).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return record;
  }

  public async getPatientRecordByIndex(patientAddress: string, index: number) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let record = await healthWalletInstance.methods.getPatientRecordByIndex(patientAddress, index).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return record;
  }

  public async getRecordFromPatientRecordsQueueByIndex(patientAddress: string, index: number) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let record = await healthWalletInstance.methods.getRecordFromPatientRecordsQueueByIndex(patientAddress, index).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return record;
  }

  public async getRecordFromMedEntityRecordsQueueByIndex(medEntityAddress: string, index: number) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let record = await healthWalletInstance.methods.getRecordFromMedEntityRecordsQueueByIndex(medEntityAddress, index).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return record;
  }

  public async getRecordFromPatientUrgencySummaryByIndex(patientAddress: string, index: number) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let record = await healthWalletInstance.methods.getRecordFromPatientUrgencySummaryByIndex(patientAddress, index).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return record;
  }

  public async getPatientRecordsCount(patientAddress: string) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let count = await healthWalletInstance.methods.getPatientRecordsCount(patientAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return count;
  }

  public async getPatientRecordsQueueCount(patientAddress: string) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let count = await healthWalletInstance.methods.getPatientRecordsQueueCount(patientAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return count;
  }

  public async getMedEntityRecordsQueueCount(medEntityAddress: string) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let count = await healthWalletInstance.methods.getMedEntityRecordsQueueCount(medEntityAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return count;
  }

  public async getPatientUrgencySummaryRecordsCount(patientAddress: string) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let count = await healthWalletInstance.methods.getPatientUrgencySummaryRecordsCount(patientAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return count;
  }

  public async getRootForRecord(recordId: number) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let root = await healthWalletInstance.methods.getRootForRecord(recordId).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return root;
  }

  public async getRecordChainGivenRoot(recordId: number) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let recordChain = await healthWalletInstance.methods.getRecordChainGivenRoot(recordId).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return recordChain;
  }

  public async getRootRecordsChainForPatient(patientAddress: string) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let rootRecords = await healthWalletInstance.methods.getRootRecordsChainForPatient(patientAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return rootRecords;
  }

  public async checkIfRecordIsForUrgency(recordId: number) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let isForUrgency = await healthWalletInstance.methods.checkIfRecordIsForUrgency(recordId).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return isForUrgency;
  }

  public async checkIfPatientIdentificationIsMatching(patientAddress: string, patientIdentification: string) {
    let healthWalletInstance = await this.web3Service.getHealthWalletContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let isMatching = await healthWalletInstance.methods.checkIfPatientIdentificationIsMatching(patientAddress, patientIdentification).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return isMatching;
  }

  // Service-level methods

  public async getPatientPendingRecords(patientAddress: string) {
    let pendingRecords = [];
    let count = await this.getPatientRecordsQueueCount(patientAddress);

    for (let i = 0; i < count; i++) {
      let pendingRecord = await this.getRecordFromPatientRecordsQueueByIndex(patientAddress, i);

      pendingRecords.push(pendingRecord);
    }

    return pendingRecords;
  }

  public async getMedEntityPendingRecords(medEntityAddress: string) {
    let pendingRecords = [];
    let count = await this.getMedEntityRecordsQueueCount(medEntityAddress);

    for (let i = 0; i < count; i++) {
      let pendingRecord = await this.getRecordFromMedEntityRecordsQueueByIndex(medEntityAddress, i);

      pendingRecords.push(pendingRecord);
    }

    return pendingRecords;
  }

  public async getRecords(patientAddress: string) {
    let records = [];
    let count = await this.getPatientRecordsCount(patientAddress);

    for (let i = 0; i < count; i++) {
      let record = await this.getPatientRecordByIndex(patientAddress, i);

      records.push(record);
    }

    return records;
  }

  public async getUrgencyOnlyRecords(patientAddress: string) {
    let records = [];
    let count = await this.getPatientUrgencySummaryRecordsCount(patientAddress);

    console.log("Urgency count: " + count);

    for (let i = 0; i < count; i++) {
      let record = await this.getRecordFromPatientUrgencySummaryByIndex(patientAddress, i);

      records.push(record);
    }

    console.log(records);
    return records;
  }
}

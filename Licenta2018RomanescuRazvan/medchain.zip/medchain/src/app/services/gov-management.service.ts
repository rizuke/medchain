import { Injectable } from '@angular/core';
import { Web3jsService } from './web3js.service';
import { Government, MedicalEntityType } from '../models';
import { ToastService } from './toast.service';

@Injectable({
  providedIn: 'root'
})
export class GovManagementService {

  constructor(private web3Service: Web3jsService, private toastService: ToastService) { }

  // Contract-level methods

  public async changeAuthority(toAddress: string): Promise<boolean> {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let authorityAddress = await govManagementInstance.methods.getAuthorityDetails().call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    })

    if (authorityAddress != currentUser) {
      return false;
    }

    await govManagementInstance.methods.changeAuthority(toAddress).send(tx).then((result) => { })
      .catch((error) => {
        console.log(error);
      });

    return true;
  }

  public async addGovernmentRequest(country: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    govManagementInstance.methods.addGovernmentRequest(country).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async removeGovernmentRequest(govAddress: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    govManagementInstance.methods.removeGovernmentRequest(govAddress).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async acceptGovernmentRequest(govAddress: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    govManagementInstance.methods.acceptGovernmentRequest(govAddress).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async declineGovernmentRequest(govAddress: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    govManagementInstance.methods.declineGovernmentRequest(govAddress).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async addGovernment(govAddress: string, country: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    govManagementInstance.methods.addGovernment(govAddress, country).send(tx).then((result) => {
      this.toastService.addSuccessMessage("Add Government", "Government added successfuly");
    }).catch((error) => {
      // console.log(error);
      this.toastService.addErrorMessage("Add Government", "Goverment addition failed");
    });
  }

  public async addMedicalEntityRequest(identification: string, govAddress: string, medicalEntityType: MedicalEntityType, isActive: boolean, begunActivity: number, suspendedActivity: number, name: string, establishmentAddress: string, fileHash: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    govManagementInstance.methods.addMedicalEntityRequest(identification, govAddress, medicalEntityType, isActive, begunActivity, suspendedActivity, name, establishmentAddress, fileHash).send(tx).then((result) => {
      this.toastService.addSuccessMessage("Medical Entity Request", "Medical entity request made successfuly");
    }).catch((error) => {
      // console.log(error);
      this.toastService.addErrorMessage("Medical Entity Request", "Error while making a medical entity request");
    });
  }

  public async removeMedicalEntityRequest(medEntityAddress: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    govManagementInstance.methods.removeMedicalEntityRequest(medEntityAddress).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async acceptMedicalEntityRequest(medEntityAddress: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    govManagementInstance.methods.acceptMedicalEntityRequest(medEntityAddress).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async declineMedicalEntityRequest(medEntityAddress: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    govManagementInstance.methods.declineMedicalEntityRequest(medEntityAddress).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async addMedicalEntity(identification: string, medicalEntityType: MedicalEntityType, isActive: boolean, begunActivity: number, suspendedActivity: number, name: string, establishmentAddress: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    govManagementInstance.methods.addMedicalEntity(identification, medicalEntityType, isActive, begunActivity, suspendedActivity, name, establishmentAddress).send(tx).then((result) => {
      this.toastService.addSuccessMessage("Medical Entity Addition", "Medical entity added successfuly");
    }).catch((error) => {
      // console.log(error);
      this.toastService.addErrorMessage("Medical Entity Addition", "Error while adding the medical entity");
    });
  }

  public async addFileHashToMedicalEntity(medEntityAddress: string, fileHash: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    govManagementInstance.methods.addFileHashToMedicalEntity(medEntityAddress, fileHash).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async beginMedicalEntityActivity(medEntityAddress: string, begunActivityDate: number) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    govManagementInstance.methods.beginMedicalEntityActivity(medEntityAddress, begunActivityDate).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async suspendMedicalEntityActivity(medEntityAddress: string, suspendedActivityDate: number) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    govManagementInstance.methods.suspendMedicalEntityActivity(medEntityAddress, suspendedActivityDate).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async getAuthorityDetails() {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let authorityDetails = await govManagementInstance.methods.getAuthorityDetails().call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return authorityDetails;
  }

  public async getGovDetails(govAddress: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let government = await govManagementInstance.methods.getGovDetails(govAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return government;
  }

  public async getGovRequestDetails(govAddress: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let governmentRequest = await govManagementInstance.methods.getGovRequestDetails(govAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return governmentRequest;
  }

  public async getMedicalEntityDetails(medEntityAddress: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let medEntity = await govManagementInstance.methods.getMedicalEntityDetails(medEntityAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return medEntity;
  }

  public async getMedicalEntityRequestDetails(medEntityAddress: string, govAddress: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let medEntityRequest = await govManagementInstance.methods.getMedicalEntityRequestDetails(medEntityAddress, govAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return medEntityRequest;
  }

  public async getMedicalEntityFileHash(medEntityAddress: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let fileHash = await govManagementInstance.methods.getMedicalEntityFileHash(medEntityAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return fileHash;
  }

  public async getGovByIndex(index: number) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let government = await govManagementInstance.methods.getGovByIndex(index).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return government;
  }

  public async getGovRequestByIndex(index: number) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let governmentRequest = await govManagementInstance.methods.getGovRequestByIndex(index).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return governmentRequest;
  }

  public async getGovMedicalEntityByIndex(govAddress: string, index: number) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let medEntity = await govManagementInstance.methods.getGovMedicalEntityByIndex(govAddress, index).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return medEntity;
  }

  public async getGovMedicalEntityRequestByIndex(govAddress: string, index: number) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let medEntityRequest = await govManagementInstance.methods.getGovMedicalEntityRequestByIndex(govAddress, index).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return medEntityRequest;
  }

  public async getGovCount() {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await govManagementInstance.methods.getGovCount().call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  public async getGovRequestsCount() {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await govManagementInstance.methods.getGovRequestsCount().call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  public async getGovMedicalEntitiesCount(govAddress: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await govManagementInstance.methods.getGovMedicalEntitiesCount(govAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  public async getGovMedicalEntitiesRequestsCount(govAddress: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await govManagementInstance.methods.getGovMedicalEntitiesRequestsCount(govAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  public async checkIfGovernmentHasMadeARequest(govAddress: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await govManagementInstance.methods.checkIfGovernmentHasMadeARequest(govAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  public async checkIfMedicalEntityHasMadeARequest(medEntityAddress: string, govAddress: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await govManagementInstance.methods.checkIfMedicalEntityHasMadeARequest(medEntityAddress, govAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  public async checkIfMedicalEntityHasMadeARequestUsingFileHash(medEntityAddress: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await govManagementInstance.methods.checkIfMedicalEntityHasMadeARequestUsingFileHash(medEntityAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  public async checkIfMedicalEntityIsActive(medEntityAddress: string) {
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await govManagementInstance.methods.checkIfMedicalEntityIsActive(medEntityAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  // Service-level methods

  public async getGovs() {
    let govs = [];
    let govsCount = await this.getGovCount();

    for (let i = 1; i < govsCount; i++) {
      let medEntity = await this.getGovByIndex(i);
      govs.push(medEntity);
    }

    return govs;
  }

  public async getGovMedicalEntities(govAddress: string) {
    let govMedicalEntities = [];
    let govMedicalEntitiesCount = await this.getGovMedicalEntitiesCount(govAddress);

    for (let i = 0; i < govMedicalEntitiesCount; i++) {
      let medEntity = await this.getGovMedicalEntityByIndex(govAddress, i);
      govMedicalEntities.push(medEntity);
    }

    return govMedicalEntities;
  }

  public async getGovMedicalEntitiesRequests(govAddress: string) {
    let requests = [];
    let requestsCount = await this.getGovMedicalEntitiesRequestsCount(govAddress);

    for (let i = 0; i < requestsCount; i++) {
      let request = await this.getGovMedicalEntityRequestByIndex(govAddress, i);
      requests.push(request);
    }

    return requests;
  }
}

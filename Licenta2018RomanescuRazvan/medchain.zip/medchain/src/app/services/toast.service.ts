import { Injectable } from '@angular/core';
import { MessageService } from 'primeng/api';

@Injectable({
  providedIn: 'root'
})
export class ToastService {

  constructor(private messageService: MessageService) { }

  addSuccessMessage(summaryMessage: string, detailsMessage: string) {
    this.messageService.add({ severity: 'success', summary: summaryMessage, detail: detailsMessage });
  }

  addInfoMessage(summaryMessage: string, detailsMessage: string) {
    this.messageService.add({ severity: 'info', summary: summaryMessage, detail: detailsMessage });
  }

  addErrorMessage(summaryMessage: string, detailsMessage: string) {
    this.messageService.add({ severity: 'error', summary: summaryMessage, detail: detailsMessage });
  }

  clear() {
    this.messageService.clear();
  }
}

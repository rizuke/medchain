import { Injectable, OnInit } from '@angular/core';
import { UserType } from '../models';
import { Web3jsService } from './web3js.service';

@Injectable({
  providedIn: 'root'
})
export class UserService implements OnInit {

  constructor(private web3Service: Web3jsService) { }

  ngOnInit(): void {
  }

  public async getUserTypeForCurrentUser(): Promise<UserType> {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let isAuthority = await addressBookInstance.methods.checkIfAddressIsAuthority(currentUser).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    if (isAuthority) {
      return UserType.Authority;
    }

    let isGov = await addressBookInstance.methods.checkIfAddressIsRegisteredGovernment(currentUser).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    if (isGov) {
      return UserType.Government;
    }

    let isMedEntity = await addressBookInstance.methods.checkIfAddressIsRegisteredMedEntity(currentUser).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();
    let isMedEntityActive = await govManagementInstance.methods.checkIfMedicalEntityIsActive(currentUser).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    if (isMedEntity) {
      if (!isMedEntityActive) {
        return UserType.Suspended;
      }
      return UserType.MedicalEntity;
    }

    let isPatient = await addressBookInstance.methods.checkIfAddressIsRegisteredPatient(currentUser).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    let isActivated = await addressBookInstance.methods.checkIfPatientIsActivated(currentUser).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    if (isPatient) {
      if (!isActivated) {
        return UserType.Pending;
      }
      else {
        return UserType.Patient;
      }
    }

    let isMedEntityRequestPending = await govManagementInstance.methods.checkIfMedicalEntityHasMadeARequestUsingFileHash(currentUser).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    if (isMedEntityRequestPending) {
      return UserType.Pending;
    }

    return UserType.Unregistered;
  }
}

import { Injectable, OnInit } from '@angular/core';
import { UserType } from '../models';
import { Web3jsService } from './web3js.service';

@Injectable({
  providedIn: 'root'
})
export class UserService implements OnInit {

  constructor(private web3Service: Web3jsService) { }

  ngOnInit(): void {
  }

  public async getUserTypeForCurrentUser(): Promise<UserType> {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let isAuthority = await addressBookInstance.methods.checkIfAddressIsAuthority(currentUser).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    let isGov = await addressBookInstance.methods.checkIfAddressIsRegisteredGovernment(currentUser).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    let isMedEntity = await addressBookInstance.methods.checkIfAddressIsRegisteredMedEntity(currentUser).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    let isPatient = await addressBookInstance.methods.checkIfAddressIsRegisteredPatient(currentUser).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    let isActivated = await addressBookInstance.methods.checkIfPatientIsActivated(currentUser).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    if (isAuthority) {
      return UserType.Authority;
    }
    else if (isGov) {
      return UserType.Government;
    }
    else if (isMedEntity) {
      return UserType.MedicalEntity;
    }
    else if (isPatient) {
      if (!isActivated) {
        return UserType.Pending;
      }
      else {
        return UserType.Patient;
      }
    }
    let govManagementInstance = await this.web3Service.getGovManagementContractInstance();
    let isMedEntityRequestPending = await govManagementInstance.methods.checkIfMedicalEntityHasMadeARequestUsingFileHash(currentUser).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    if (isMedEntityRequestPending) {
      return UserType.Pending;
    }

    return UserType.Unregistered;
  }
}

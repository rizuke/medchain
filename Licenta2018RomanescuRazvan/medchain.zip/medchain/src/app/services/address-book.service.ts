import { Injectable } from '@angular/core';
import { Web3jsService } from './web3js.service';
import { ToastService } from './toast.service';

@Injectable({
  providedIn: 'root'
})
export class AddressBookService {

  constructor(
    private web3Service: Web3jsService,
    private toastService: ToastService) { }

  // Contract-level methods

  public async registerPatientIdentification(personalIdentification: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    addressBookInstance.methods.addPatientDetails(personalIdentification).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async addPatientDetails(identification: string, firstName: string, lastName: string, birthDate: number, residency: string, medEntityAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    addressBookInstance.methods.addPatientDetails(identification, firstName, lastName, birthDate, residency, medEntityAddress).send(tx).then((result) => {
      this.toastService.addSuccessMessage("Patient Registration", "Patient added successfully");
    }).catch((error) => {
      // console.log(error);
      this.toastService.addErrorMessage("Patient Registration", "Error while trying to register the patient");
    });
  }

  public async addPatientRequestToMedicalEntity(patientAddress: string, medEntityAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    addressBookInstance.methods.addPatientRequestToMedicalEntity(patientAddress, medEntityAddress).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async addPatientToMedicalEntity(patientAddress: string, medEntityAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    addressBookInstance.methods.addPatientToMedicalEntity(patientAddress, medEntityAddress).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async acceptPatientRequestToMedicalEntity(patientAddress: string, medEntityAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    addressBookInstance.methods.acceptPatientRequestToMedicalEntity(patientAddress, medEntityAddress).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async declinePatientRequestToMedicalEntity(patientAddress: string, medEntityAddress: string, reason: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    addressBookInstance.methods.declinePatientRequestToMedicalEntity(patientAddress, medEntityAddress, reason).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async removePatientFromMedicalEntity(patientAddress: string, medEntityAddress: string, reason: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    addressBookInstance.methods.removePatientFromMedicalEntity(patientAddress, medEntityAddress, reason).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async getPatientDetails(patientAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let patient = await addressBookInstance.methods.getPatientDetails(patientAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return patient;
  }

  public async getPatientMedicalEntitiesCount(patientAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let count = await addressBookInstance.methods.getPatientMedicalEntitiesCount(patientAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return count;
  }

  public async getMedicalEntityPatientsCount(medEntityAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let count = await addressBookInstance.methods.getMedicalEntityPatientsCount(medEntityAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return count;
  }

  public async getMedicalEntityPatientRequestsCount(medEntityAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let count = await addressBookInstance.methods.getMedicalEntityPatientRequestsCount(medEntityAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return count;
  }

  public async getPatientDetailsForMedicalEntityByIndex(medEntityAddress: string, index: number) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let patient = await addressBookInstance.methods.getPatientDetailsForMedicalEntityByIndex(medEntityAddress, index).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return patient;
  }

  public async getMedicalEntityDetailsForPatientByIndex(patientAddress: string, index: number) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let medEntity = await addressBookInstance.methods.getMedicalEntityDetailsForPatientByIndex(patientAddress, index).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return medEntity;
  }

  public async checkIfPatientIsAssociatedToMedEntity(patientAddress: string, medEntityAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await addressBookInstance.methods.checkIfPatientIsAssociatedToMedEntity(patientAddress, medEntityAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  public async checkIfAddressIsRegisteredPatient(addressInput: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await addressBookInstance.methods.checkIfAddressIsRegisteredPatient(addressInput).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  public async checkIfAddressIsRegisteredMedEntity(addressInput: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await addressBookInstance.methods.checkIfAddressIsRegisteredMedEntity(addressInput).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  public async checkIfAddressIsRegisteredGovernment(addressInput: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await addressBookInstance.methods.checkIfAddressIsRegisteredGovernment(addressInput).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  public async checkIfAddressIsAuthority(addressInput: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await addressBookInstance.methods.checkIfAddressIsAuthority(addressInput).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  public async checkIfPatientIsActivated(patientAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await addressBookInstance.methods.checkIfPatientIsActivated(patientAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  // Service-level methods

}

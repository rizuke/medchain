import { Injectable } from '@angular/core';
import { Web3jsService } from './web3js.service';
import { ToastService } from './toast.service';
import { EncryptionService } from './encryption.service';

@Injectable({
  providedIn: 'root'
})
export class AddressBookService {

  constructor(
    private web3Service: Web3jsService,
    private encryptionService: EncryptionService,
    private toastService: ToastService) { }

  // Contract-level methods

  public async registerPatientIdentification(personalIdentification: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    addressBookInstance.methods.registerPatientIdentification(personalIdentification).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async addPatientDetails(identification: string, firstName: string, lastName: string, birthDate: number, residency: string, medEntityAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    addressBookInstance.methods.addPatientDetails(identification, firstName, lastName, birthDate, residency, medEntityAddress).send(tx).then((result) => {
      this.toastService.addSuccessMessage("Patient Registration", "Patient added successfully");
    }).catch((error) => {
      // console.log(error);
      this.toastService.addErrorMessage("Patient Registration", "Error while trying to register the patient");
    });
  }

  public async addPatientRequestToMedicalEntity(patientAddress: string, medEntityAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    addressBookInstance.methods.addPatientRequestToMedicalEntity(patientAddress, medEntityAddress).send(tx).then((result) => {
      this.toastService.addSuccessMessage("Medical Entity Request", "Patient request to medical entity made successfully");
    }).catch((error) => {
      // console.log(error);
      this.toastService.addErrorMessage("Medical Entity Request", "Error while trying to add patient request to medical entity");
    });
  }

  public async addPatientToMedicalEntity(patientAddress: string, medEntityAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    addressBookInstance.methods.addPatientToMedicalEntity(patientAddress, medEntityAddress).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async acceptPatientRequestToMedicalEntity(patientAddress: string, medEntityAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    addressBookInstance.methods.acceptPatientRequestToMedicalEntity(patientAddress, medEntityAddress).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async declinePatientRequestToMedicalEntity(patientAddress: string, medEntityAddress: string, reason: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    addressBookInstance.methods.declinePatientRequestToMedicalEntity(patientAddress, medEntityAddress, reason).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async removePatientRequestFromMedicalEntity(patientAddress: string, medEntityAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    addressBookInstance.methods.removePatientRequestFromMedicalEntity(patientAddress, medEntityAddress).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async removePatientFromMedicalEntity(patientAddress: string, medEntityAddress: string, reason: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    addressBookInstance.methods.removePatientFromMedicalEntity(patientAddress, medEntityAddress, reason).send(tx).then((result) => {
    }).catch((error) => {
      console.log(error);
    });
  }

  public async getPatientDetails(patientAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let patient = await addressBookInstance.methods.getPatientDetails(patientAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return patient;
  }

  public async getPatientMedicalEntitiesCount(patientAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let count = await addressBookInstance.methods.getPatientMedicalEntitiesCount(patientAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return count;
  }

  public async getMedicalEntityPatientsCount(medEntityAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let count = await addressBookInstance.methods.getMedicalEntityPatientsCount(medEntityAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return count;
  }

  public async getMedicalEntityPatientRequestsCount(medEntityAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let count = await addressBookInstance.methods.getMedicalEntityPatientRequestsCount(medEntityAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return count;
  }

  public async getPatientDetailsForMedicalEntityByIndex(medEntityAddress: string, index: number) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let patient = await addressBookInstance.methods.getPatientDetailsForMedicalEntityByIndex(medEntityAddress, index).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return patient;
  }

  public async getMedicalEntityDetailsForPatientByIndex(patientAddress: string, index: number) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let medEntity = await addressBookInstance.methods.getMedicalEntityDetailsForPatientByIndex(patientAddress, index).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return medEntity;
  }

  public async getMedicalEntityPatientRequestByIndex(medEntityAddress: string, index: number) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let request = await addressBookInstance.methods.getMedicalEntityPatientRequestByIndex(medEntityAddress, index).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return request;
  }

  public async getPatientAddressGivenIdentification(patientIdentification: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    let patientAddress = await addressBookInstance.methods.getPatientAddressGivenIdentification(patientIdentification).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });

    return patientAddress;
  }

  public async checkIfPatientIsAssociatedToMedEntity(patientAddress: string, medEntityAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await addressBookInstance.methods.checkIfPatientIsAssociatedToMedEntity(patientAddress, medEntityAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  public async checkIfAddressIsRegisteredPatient(addressInput: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await addressBookInstance.methods.checkIfAddressIsRegisteredPatient(addressInput).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  public async checkIfAddressIsRegisteredMedEntity(addressInput: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await addressBookInstance.methods.checkIfAddressIsRegisteredMedEntity(addressInput).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  public async checkIfAddressIsRegisteredGovernment(addressInput: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await addressBookInstance.methods.checkIfAddressIsRegisteredGovernment(addressInput).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  public async checkIfAddressIsAuthority(addressInput: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await addressBookInstance.methods.checkIfAddressIsAuthority(addressInput).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  public async checkIfPatientIsActivated(patientAddress: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await addressBookInstance.methods.checkIfPatientIsActivated(patientAddress).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  public async checkIfPatientIdentificationIsMatching(patientAddress: string, patientIdentification: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await addressBookInstance.methods.checkIfPatientIdentificationIsMatching(patientAddress, patientIdentification).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  public async checkIfPatientIdentificationExists(patientIdentification: string) {
    let addressBookInstance = await this.web3Service.getAddressBookContractInstance();

    let currentUser = this.web3Service.getCurrentAccount();
    let tx = { from: currentUser };

    return await addressBookInstance.methods.checkIfPatientIdentificationExists(patientIdentification).call(tx, (error, result) => {
      if (error != null) {
        console.log(error);
      }
    });
  }

  // Service-level methods
  public async getPatientRequests(medEntityAddress: string) {
    let requests = [];
    let requestsCount = await this.getMedicalEntityPatientRequestsCount(medEntityAddress);

    for (let i = 0; i < requestsCount; i++) {
      let request = await this.getMedicalEntityPatientRequestByIndex(medEntityAddress, i);
      let patientDetails = await this.getPatientDetails(request);

      requests.push(patientDetails);
    }

    return requests;
  }

  public async getPatients(medEntityAddress: string) {
    let patients = [];
    let patientsCount = await this.getMedicalEntityPatientsCount(medEntityAddress);

    for (let i = 0; i < patientsCount; i++) {
      let patientDetails = await this.getPatientDetailsForMedicalEntityByIndex(medEntityAddress, i);

      patients.push(patientDetails);
    }

    return patients;
  }

  public async getMedEntities(patientAddress: string) {
    let medEntities = [];
    let medEntitiesCount = await this.getPatientMedicalEntitiesCount(patientAddress);

    for (let i = 0; i < medEntitiesCount; i++) {
      let medEntity = await this.getMedicalEntityDetailsForPatientByIndex(patientAddress, i);

      medEntities.push(medEntity);
    }

    return medEntities;
  }
}

import { Injectable } from '@angular/core';

@Injectable()
export class MobileService {

    getIsMobile() {
        if (/Android|webOS|iPhone|iPad|BlackBerry|Windows Phone|Opera Mini|IEMobile|Mobile/i.test(navigator.userAgent)) {
            return true;
        }
        return false;
    }

    getIsIosDevice() {
        if (/iPhone|iPad/i.test(navigator.userAgent)) {
            return true;
        }
        return false;
    }
}

import { Injectable } from '@angular/core';

declare let require: any;

const IPFS = require('ipfs-http-client');
const ipfs = new IPFS({host: 'ipfs.infura.io', port: 5001, protocol: 'https'});

@Injectable({
  providedIn: 'root'
})
export class IpfsService {
  public ipfsObject;

  constructor() { 
    this.ipfsObject = ipfs;
  }
}

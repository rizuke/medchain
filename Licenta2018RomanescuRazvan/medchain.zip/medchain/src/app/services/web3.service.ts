import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

declare let require: any;
declare let window: any;

const Web3 = require('web3');

const govManagementJson = require('./../../../build/contracts/GovManagement.json');
const addressBookJson = require('./../../../build/contracts/AddressBook.json');
const healthWalletJson = require('./../../../build/contracts/HealthWallet.json');

@Injectable({
  providedIn: 'root'
})
export class Web3Service {
  private web3Object: any;
  private accounts: string[];
  public ready = false;

  public accountsObservable = new Subject<string[]>();

  constructor() {
    window.addEventListener('load', (event) => {
      this.bootstrapWeb3();
    });
  }

  public bootstrapWeb3() {
    // Checking if Web3 has been injected by the browser (Mist/MetaMask)
    if (typeof window.web3 !== 'undefined') {
      // Use Mist/MetaMask's provider
      this.web3Object = new Web3(window.web3.currentProvider);
    } else {
      console.log('No web3? You should consider trying MetaMask!');

      // Hack to provide backwards compatibility for Truffle, which uses web3js 0.20.x
      Web3.providers.HttpProvider.prototype.sendAsync = Web3.providers.HttpProvider.prototype.send;
      // fallback - use your fallback strategy (local node / hosted node + in-dapp id mgmt / fail)
      this.web3Object = new Web3(new Web3.providers.HttpProvider('http://localhost:8545'));
    }

    setInterval(() => this.refreshAccounts(), 100);
  }

  private refreshAccounts() {
    this.web3Object.eth.getAccounts((err, accs) => {
      console.log('Refreshing accounts');
      if (err != null) {
        console.warn('There was an error fetching your accounts.');
        return;
      }

      // Get the initial account balance so it can be displayed.
      if (accs.length === 0) {
        console.warn('Couldn\'t get any accounts! Make sure your Ethereum client is configured correctly.');
        return;
      }

      if (!this.accounts || this.accounts.length !== accs.length || this.accounts[0] !== accs[0]) {
        console.log('Observed new accounts');

        this.accountsObservable.next(accs);
        this.accounts = accs;
      }

      this.ready = true;
    });
  }

  public async getGovManagementContractInstance() {
    const networkId = await this.web3Object.eth.net.getId();
    const deployedAddress = govManagementJson.networks[networkId].address;

    const contract = new this.web3Object.eth.Contract(govManagementJson.abi, deployedAddress);

    return contract;
  }

  public async getAddressBookContractInstance() {
    const networkId = await this.web3Object.eth.net.getId();
    const deployedAddress = addressBookJson.networks[networkId].address;

    const contract = new this.web3Object.eth.Contract(addressBookJson.abi, deployedAddress);

    return contract;
  }

  public async getHealthWalletContractInstance() {
    const networkId = await this.web3Object.eth.net.getId();
    const deployedAddress = healthWalletJson.networks[networkId].address;

    const contract = new this.web3Object.eth.Contract(healthWalletJson.abi, deployedAddress);

    return contract;
  }
}

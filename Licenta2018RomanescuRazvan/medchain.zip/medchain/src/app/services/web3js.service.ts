import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

declare let require: any;
declare let window: any;

const Web3 = require('web3');

const govManagementJson = require('./../../../build/contracts/GovManagement.json');
const addressBookJson = require('./../../../build/contracts/AddressBook.json');
const healthWalletJson = require('./../../../build/contracts/HealthWallet.json');

@Injectable({
    providedIn: 'root'
})
export class Web3jsService {
    private web3Object: any;

    public currentAccount: string;
    public currentUserType: string;
    private accounts: string[];

    public accountsObservable = new Subject<string[]>();

    constructor() {
        this.bootstrapWeb3();
    }

    private bootstrapWeb3() {
        window.addEventListener('load', async () => {
            if (window.ethereum) {
                this.web3Object = new Web3(window.ethereum);

                try {
                    await window.ethereum.enable();
                } catch (error) {
                    console.log(error);
                }
            }
            else if (window.web3) {
                this.web3Object = new Web3(window.web3.currentProvider);
            }
            else {
                this.web3Object = new Web3(new Web3.providers.HttpProvider('http://localhost:8545'));
            }

            setInterval(() => this.refreshAccounts(), 100);
            return this.web3Object;
        })
    }

    private refreshAccounts() {
        this.web3Object.eth.getAccounts((err, accs) => {
            console.log('Refreshing accounts');
            if (err != null) {
                console.warn('There was an error fetching your accounts.');
                return;
            }

            // Get the initial account balance so it can be displayed.
            if (accs.length === 0) {
                console.warn('Couldn\'t get any accounts! Make sure your Ethereum client is configured correctly.');
                return;
            }

            if (!this.accounts || this.accounts.length !== accs.length || this.accounts[0] !== accs[0]) {
                console.log('Observed new accounts');

                this.accountsObservable.next(accs);
                this.accounts = accs;
                this.currentAccount = accs[0];
            }
        });
    }

    public getCurrentAccount() {
        return this.accounts[0];
    }

    public async getGovManagementContractInstance() {
        const networkId = await this.web3Object.eth.net.getId();
        const deployedAddress = govManagementJson.networks[networkId].address;

        const contract = new this.web3Object.eth.Contract(govManagementJson.abi, deployedAddress);

        return contract;
    }

    public async getAddressBookContractInstance() {
        const networkId = await this.web3Object.eth.net.getId();
        const deployedAddress = addressBookJson.networks[networkId].address;

        const contract = new this.web3Object.eth.Contract(addressBookJson.abi, deployedAddress);

        return contract;
    }

    public async getHealthWalletContractInstance() {
        const networkId = await this.web3Object.eth.net.getId();
        const deployedAddress = healthWalletJson.networks[networkId].address;

        const contract = new this.web3Object.eth.Contract(healthWalletJson.abi, deployedAddress);

        return contract;
    }
}

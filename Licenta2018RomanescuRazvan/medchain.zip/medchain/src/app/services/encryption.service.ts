import { Injectable } from '@angular/core';

declare let require: any;
const Blowfish = require('javascript-blowfish');

@Injectable({
  providedIn: 'root'
})
export class EncryptionService {

  constructor() { }

  public encrypt(key: string, message: string): string {
    let bf = new Blowfish(key);

    let encryptedMessage = bf.encrypt(message);
    let result = bf.base64Encode(encryptedMessage);

    return result;
  }

  public decrypt(key: string, encryptedMessage: string): string {
    const bf = new Blowfish(key);

    const message = bf.base64Decode(encryptedMessage);
    let result = bf.decrypt(message);
    result = bf.trimZeros(result);

    return result;
  }
}

import { Routes } from '@angular/router';

import {
    AddressBookComponent,
    PendingComponent,
    ProfileComponent,
    NotFoundComponent,
    GovernmentManagementComponent,
    GovernmentListComponent,
    MedEntityManagementComponent,
    MedEntityRequestsComponent,
    LandingPageComponent,
    RegisterPatientComponent,
    RegisterMedComponent
} from './components';

export const appRoutes: Routes = [
    { path: 'profile', component: ProfileComponent },
    { path: 'authority/govs', component: GovernmentListComponent },
    { path: 'authority/management', component: GovernmentManagementComponent },
    { path: 'gov/profile', component: ProfileComponent },
    { path: 'gov/requests', component: MedEntityRequestsComponent },
    { path: 'gov/medentities', component: MedEntityManagementComponent },
    { path: 'patient/register', component: RegisterPatientComponent },
    { path: 'med/register', component: RegisterMedComponent },
    { path: 'addressbook', component: AddressBookComponent },
    { path: 'pending', component: PendingComponent },
    { path: '404', component: NotFoundComponent },
    { path: '', component: LandingPageComponent },
    // { path: '', redirectTo: '/profile', pathMatch: 'full' }
]

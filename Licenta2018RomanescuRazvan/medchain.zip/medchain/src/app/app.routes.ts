import { Routes } from '@angular/router';

import {
    ProfileComponent,
    NotFoundComponent,
    GovernmentManagementComponent,
    GovernmentListComponent,
    MedEntityManagementComponent,
    MedEntityRequestsComponent,
    LandingPageComponent,
    RegisterPatientComponent,
    RegisterMedComponent,
    AddMedEntityComponent,
    MedEntityAddressBookComponent,
    WriteRecordComponent,
    PatientAddressBookComponent,
    PatientPendingRecordsComponent,
    MedPendingRecordsComponent,
    PatientRecordHistoryComponent,
    MedPatientRecordHistoryComponent
} from './components';

export const appRoutes: Routes = [
    { path: 'profile', component: ProfileComponent },
    { path: 'authority/govs', component: GovernmentListComponent },
    { path: 'authority/management', component: GovernmentManagementComponent },
    { path: 'gov/profile', component: ProfileComponent },
    { path: 'gov/addmed', component: AddMedEntityComponent },
    { path: 'gov/requests', component: MedEntityRequestsComponent },
    { path: 'gov/medentities', component: MedEntityManagementComponent },
    { path: 'med/register', component: RegisterMedComponent },
    { path: 'med/addressbook', component: MedEntityAddressBookComponent },
    { path: 'med/pending', component: MedPendingRecordsComponent },
    { path: 'med/write', component: WriteRecordComponent },
    { path: 'med/patienthistory', component: MedPatientRecordHistoryComponent },
    { path: 'patient/register', component: RegisterPatientComponent },
    { path: 'patient/addressbook', component: PatientAddressBookComponent },
    { path: 'patient/pending', component: PatientPendingRecordsComponent },
    { path: 'patient/history', component: PatientRecordHistoryComponent },
    { path: '404', component: NotFoundComponent },
    { path: '', component: LandingPageComponent },
    { path: 'landing', redirectTo: '', pathMatch: 'full' }
]

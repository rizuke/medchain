import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LayoutModule } from '@angular/cdk/layout';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { CommonModule } from '@angular/common';

// PrimeNG
import { PrimeNgModule } from './ui-modules/primeng.module';

// Angular Material
import { MaterialModule } from './ui-modules/material.module';

// Angular Flex Layout
import { FlexLayoutModule } from '@angular/flex-layout';

// Fontawesome icons
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { library } from '@fortawesome/fontawesome-svg-core';
import { faBars } from '@fortawesome/free-solid-svg-icons';

// Components & Services
import {
  Web3Service,
  Web3jsService,
  IpfsService,
  UserService,
  EncryptionService,
  MobileService,
  GovManagementService,
  AddressBookService,
  HealthWalletService,
  ToastService
} from './services';
import {
  AddressBookComponent,
  SideMenuItemsComponent,
  PendingComponent,
  NotFoundComponent,
  ProfileComponent,
  GovernmentManagementComponent,
  GovernmentListComponent,
  AddGovComponent,
  GovernmentDetailsComponent,
  MedEntityManagementComponent,
  MedEntityRequestsComponent,
  LandingPageComponent,
  RegisterPatientComponent,
  RegisterMedComponent,
  MedEntityRequestDetailsComponent
} from './components';

// Routing
import { appRoutes } from './app.routes';

// Nebular
import {
  NbThemeModule,
  NbLayoutModule,
  NbSidebarModule,
  NbSidebarService,
  NbMenuModule,
  NbActionsModule
} from '@nebular/theme';

@NgModule({
  declarations: [
    AppComponent,
    AddressBookComponent,
    SideMenuItemsComponent,
    PendingComponent,
    NotFoundComponent,
    ProfileComponent,
    GovernmentManagementComponent,
    GovernmentListComponent,
    AddGovComponent,
    GovernmentDetailsComponent,
    MedEntityManagementComponent,
    MedEntityRequestsComponent,
    LandingPageComponent,
    RegisterPatientComponent,
    RegisterMedComponent,
    MedEntityRequestDetailsComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    RouterModule.forRoot(appRoutes),
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MaterialModule,
    PrimeNgModule,
    FlexLayoutModule,
    FontAwesomeModule,
    LayoutModule,
    NbThemeModule.forRoot({ name: 'corporate' }),
    NbLayoutModule,
    NbSidebarModule.forRoot(),
    NbMenuModule.forRoot(),
    NbActionsModule
  ],
  providers: [
    Web3Service,
    Web3jsService,
    IpfsService,
    GovManagementService,
    AddressBookService,
    HealthWalletService,
    UserService,
    EncryptionService,
    ToastService,
    MobileService,
    NbSidebarService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor() {
    library.add(faBars)
  }
}

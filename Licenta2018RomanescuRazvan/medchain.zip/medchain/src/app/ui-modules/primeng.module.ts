import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ToastModule } from 'primeng/toast';
import { InputTextModule } from 'primeng/inputtext';
import { CalendarModule } from 'primeng/calendar';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DataViewModule } from 'primeng/dataview';

import { MessageService } from 'primeng/api';

@NgModule({
    declarations: [],
    imports: [
        CommonModule,
        ToastModule,
        InputTextModule,
        CalendarModule,
        ButtonModule,
        CardModule,
        DataViewModule
    ],
    exports: [
        CommonModule,
        ToastModule,
        InputTextModule,
        CalendarModule,
        ButtonModule,
        CardModule,
        DataViewModule
    ],
    providers: [
        MessageService
    ]
})
export class PrimeNgModule { }

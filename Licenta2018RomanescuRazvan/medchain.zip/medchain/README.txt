*INSTALLATION STEPS*

Install Ganache
Install Node.js
Install Metamask extension for your browser
"npm install" in the medchain folder
Open Ganache and tie your local Ethereum node to the Metamask through the seed words
"truffle migrate --reset" in the medchain folder
"ng serve --open"

Import one or more accounts in your Metamask account from the local Ganache to play with the app

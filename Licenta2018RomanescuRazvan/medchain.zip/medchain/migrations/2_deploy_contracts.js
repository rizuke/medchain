var Domain = artifacts.require("./Domain.sol");
var AddressBook = artifacts.require("./AddressBook.sol");
var GovManagement = artifacts.require("./GovManagement.sol");
var HealthWallet = artifacts.require("./HealthWallet.sol");

module.exports = async function(deployer) {
  await deployer.deploy(Domain);
  await deployer.link(Domain, GovManagement);
  await deployer.link(Domain, AddressBook);
  await deployer.link(Domain, HealthWallet);
  await deployer.deploy(GovManagement);
  await deployer.deploy(AddressBook, GovManagement.address);
  await deployer.deploy(HealthWallet, AddressBook.address);
};
